const crypto = require("crypto");

class EncryptionHelper {
  static encrypt(plainText, password, salt) {
    // Derive key using PBKDF2 (same as Rfc2898DeriveBytes in C#)
    const key = crypto.pbkdf2Sync(password, Buffer.from(salt, "utf8"), 10000, 32, "sha1");

    // Generate random IV (16 bytes for AES-CBC)
    const iv = crypto.randomBytes(16);

    const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
    let encrypted = cipher.update(plainText, "utf8", "binary");
    encrypted += cipher.final("binary");

    // Prepend IV to ciphertext
    const encryptedBytes = Buffer.concat([iv, Buffer.from(encrypted, "binary")]);

    // Return Base64
    return encryptedBytes.toString("base64");
  }

  static decrypt(cipherText, password, salt) {
    const fullCipher = Buffer.from(cipherText, "base64");

    // Extract IV (first 16 bytes)
    const iv = fullCipher.subarray(0, 16);
    const encrypted = fullCipher.subarray(16);

    // Derive key
    const key = crypto.pbkdf2Sync(password, Buffer.from(salt, "utf8"), 10000, 32, "sha1");

    const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = decipher.update(encrypted, "binary", "utf8");
    decrypted += decipher.final("utf8");

    return decrypted;
  }
}

module.exports = EncryptionHelper;
