const modules = global.modules;
const path = modules.require("path");
const { GenericScriptBase, bfs, util } = modules;
let modPath = require.resolve("./HttpHelper");
delete require.cache[modPath];
const HttpHelper = require(modPath);

modPath = require.resolve("./common");
delete require.cache[modPath];
const { GetAuthTokent, getHostDetails } = require(modPath);

class InteractiveAIConnector extends GenericScriptBase {
  async process() {
    let self = this;
    let inputData = self.data;

    Object.keys(self.scriptParams).forEach(key => {
      inputData[key] = self.scriptParams[key];
    });

    try {
      inputData.received_date = inputData.received_date ? new Date(inputData.received_date).toISOString() : new Date().toISOString();

      if (inputData.email_message.indexOf("Confidence of Classification") != -1 && inputData.email_message.indexOf("iris@featsystems.com") != -1) {
        return { rc: 1, msg: 'Email -IRIS Auto Replied Email' }
      }

      let requestbody = `{"texts":[{"id":"${inputData.buss_id}","text":"${inputData.subject}\n${inputData.email_message}"}]}`;
      requestbody = requestbody.replace(/\r?\n|\r/g, " ");
      // var jsonObject = JSON.stringify(JSON.parse(JSON.parse(requestbody)));
      this.httpHelper = new HttpHelper("http", { encrypt: true, crypto_pwd: inputData.crypto_pwd, crypto_salt: inputData.crypto_salt });
      let token = await GetAuthTokent(inputData, this.httpHelper);

      var postheaders = {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(requestbody, "utf8"),
        Authorization: `Bearer ${token}`,
      };

      var optionspost = {
        path: `/${inputData.model}/${inputData.serviceId}/${inputData.inference_api}`.replace("//", "/"),
        method: "POST",
        headers: postheaders,
        rejectUnauthorized: false
      };

      optionspost = { ...optionspost, ...getHostDetails(inputData) };
      var rparesponse;

      rparesponse = await this.httpHelper.postRequest({
        requestoption: optionspost,
        data: requestbody,
      });
      if (rparesponse && rparesponse.results && rparesponse.results.length > 0) {
        console.log("Comm-Response:" + JSON.stringify(rparesponse) + "");
        inputData.com_mining_response = rparesponse;

        var responsData = rparesponse.results[0];

        console.log(JSON.stringify(responsData) + "");

        if (responsData) {
          let classification_result = responsData.result.filter(cs => {
            return cs.from_name == 'classification';
          });

          let sentiment_result = responsData.result.filter(cs => {
            return cs.from_name == 'sentiment';
          });

          if (classification_result && classification_result.length > 0) {
            inputData.cs_query_type = classification_result[0].value.taxonomy[0].join(" > ");
            inputData.confidence = classification_result[0].value.score * 100;
            inputData.confidence_val = inputData.confidence;
          }
          if (sentiment_result && sentiment_result.length > 0) {
            inputData.classified_sentiment = sentiment_result[0].value.taxonomy[0];
            inputData.sentiment = sentiment_result[0].value.score * 100;
          }

        }
        else {
          inputData.cs_query_type = "";
          inputData.confidence = 0;
          inputData.confidence_val = 0;
          inpoutData.sentiment = 0;
        }
        return {
          rc: 0, data: inputData
        };
      } else return { rc: 0, msg: "Error" };
    } catch (e) {
      return { rc: 1, msg: `Error: ${e.message || e.response}` };
    }

    let rslt;

    let rsltData = {};
    return { rc: 0, data: rsltData };
  }

  CleanUpData(strContent) {
    if (!strContent)
      return "";
    let _str = strContent;
    _str = _str.replaceAll('"', "");
    _str = _str.replaceAll("'", "");
    return _str;
  }


}
module.exports = InteractiveAIConnector;