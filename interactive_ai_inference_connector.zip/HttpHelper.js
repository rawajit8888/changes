const https = require('https');
const http = require('http');
let modPath = require.resolve("./cryptohelper");
delete require.cache[modPath];
const { encrypt, decrypt } = require(modPath);

class HttpHelper {
    constructor(type = 'https', options = {}) {
        this.type = type;
        this.requestProvider = this.provider;
        this.options = options;
    }
    get provider() {
        return this.type == 'https' ? https : http;
    }
    postRequest(options) {
        let cInstance = this;
        const { requestoption, data } = options;
        let _data = this.encrypt_decrypt(data, 'encrypt');
        const body = Buffer.from(_data, 'utf8');

        requestoption.headers['Content-Length']= Buffer.byteLength(body);      

        return new Promise((resolve, reject) => {
            const req = cInstance.requestProvider.request(requestoption, (res) => {
                res.setEncoding('utf8');
                let responseBody = '';

                res.on('data', (chunk) => {
                    responseBody += chunk;
                });

                res.on('end', () => {
                    let _responsebody = this.encrypt_decrypt(responseBody, 'decrypt');
                    if (res.statusCode == 200 || res.statusCode == 201)
                        resolve(JSON.parse(_responsebody));
                    else
                        reject({ status: res.statusCode, response: _responsebody });
                });
            });

            req.on('error', (err) => {
                reject(err);
            });

            req.write(_data)
            req.end();
        })
    }

    getRequest(options) {
        let cInstance = this;
        const { requestoption } = options;
        return new Promise((resolve, reject) => {
            const req = cInstance.requestProvider.get(requestoption, (res) => {
                res.setEncoding('utf8');
                let responseBody = '';

                res.on('data', (chunk) => {
                    responseBody += chunk;
                });

                res.on('end', () => {
                    let _responsebody = this.encrypt_decrypt(responseBody, 'decrypt');
                    if (res.statusCode == 200 || res.statusCode == 201)
                        resolve(JSON.parse(_responsebody));
                    else
                        reject({ status: res.statusCode, response: _responsebody });
                });
            });

            req.on('error', (err) => {
                reject(err);
            });
        });
    }

    encrypt_decrypt(data, mode) {
        var _data = data;
        if (data && this.options && this.options.encrypt === true) {
            if (mode == 'encrypt') {
                _data = encrypt(data, this.options.crypto_pwd, this.options.crypto_salt);
            }
            else {
                _data = decrypt(data, this.options.crypto_pwd, this.options.crypto_salt);
            }
        }
        return _data;
    }

}

module.exports = HttpHelper;