import base64
import json
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os

from dotenv import load_dotenv
from pathlib import Path

dotenv_path = Path('C:/Users/vaibhav/AppData/Local/label-studio/label-studio/.env')

load_dotenv(dotenv_path=dotenv_path)

OAUTH_API_ENC_PWD = os.getenv('OAUTH_API_ENC_PWD')
OAUTH_API_ENC_SALT = os.getenv('OAUTH_API_ENC_SALT')


class CryptoHelper:
    @staticmethod
    def _derive_key(password: str, salt: str) -> bytes:
        """Derive a 32-byte key using PBKDF2-HMAC-SHA1"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA1(),
            length=32,
            salt=salt.encode('utf-8'),
            iterations=10000,
            backend=default_backend()
        )
        return kdf.derive(password.encode('utf-8'))

    @staticmethod
    def encrypt(plain_text: str) -> str:
        key = CryptoHelper._derive_key(OAUTH_API_ENC_PWD, OAUTH_API_ENC_SALT)
        iv = os.urandom(16)

        # AES-CBC encryption
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()

        # PKCS7 padding
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(json.dumps(plain_text).encode('utf-8')) + padder.finalize()

        ciphertext = encryptor.update(padded_data) + encryptor.finalize()
        return base64.b64encode(iv + ciphertext).decode('utf-8')

    @staticmethod
    def decrypt(cipher_text: str) -> str:
        full_cipher = base64.b64decode(cipher_text)
        iv = full_cipher[:16]
        ciphertext = full_cipher[16:]

        key = CryptoHelper._derive_key(OAUTH_API_ENC_PWD, OAUTH_API_ENC_SALT)

        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded_plain = decryptor.update(ciphertext) + decryptor.finalize()

        # Remove PKCS7 padding
        unpadder = padding.PKCS7(128).unpadder()
        plain_text = unpadder.update(padded_plain) + unpadder.finalize()

        return plain_text.decode('utf-8')
